import axios from 'axios';
import instance from './header.js'
const request = class{
	constructor(url,arg) {
	  // 请求地址
	  this.url = url
	  // 请求参数
	  this.arg = arg
	}
	
	// post请求
	modepost(){
		return new Promise((resolve,reject)=>{
		  instance.post((this.url),this.arg)
		  .then((res)=>{
		    resolve(res)
		  })
		  .catch((err)=>{
		    reject(err)
		  })
		})
	}
	
	// get请求
	modeget(){
		return new Promise((resolve,reject)=>{
		  instance.get((this.url))
		  .then((res)=>{
		    resolve(res)
		  })
		  .catch((err)=>{
		    reject(err)
		  })
		})
	}
}

export default request
