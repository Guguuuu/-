<template>
	<view class="body">
		
	</view>
</template>

<script>
</script>

<style>
	.body {
		width: 100%;
		height: 100vh;
		background-image: url('https://guguuuu-1313746603.cos.ap-guangzhou.myqcloud.com/image/%E5%B0%8F%E7%A8%8B%E5%BA%8F%E9%A6%96%E9%A1%B5.jpg');
		background-attachment: fixed;
		background-repeat: no-repeat;
		background-size: 90% 70%;
		background-position: center;
	}
	page{
		background-image: linear-gradient(to right,#6b8e91,#cadce3);
	}
</style>
