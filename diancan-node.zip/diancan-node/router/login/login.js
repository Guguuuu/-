// -----------------------------注册-登录-接口----------------------
const router = require('koa-router')()//实例化new路由
// 引入统一给前端返回的body响应
const result = require('../../config/result.js')
// 操作数据库的接口
const {getToken,Addurl,Tripurl} = require('../../config/databaseapi.js')
// 校验
const {regcheck} = require('../../config/checking.js')
// 生成token
const {gentoken} = require('../../token/jwt.js')
// 验证token合法性
const {Auth} = require('../../token/auth.js')

// 注册接口
// 区别于express框架的路由，express的路由所映射的 函数 的参数是req和res，koa把这俩封装成了content，变成了一个。
router.post('/register', async ctx=>{
	
	// post提交的值在：ctx.request.body
	let {account,password} = ctx.request.body // 通过结构赋值来拿我想要的字段，如果在下面的校验中出现undefined，说明前端参数填错了。
	
	// 1:校验前端传来的值是否合法
	new regcheck(ctx,account,password).start()
	
	console.log('1234')
	
	// 2.查询手机号码之前是否已经注册过
	const query = `db.collection('business-acc').where({account:'${account}'}).get()`
	try{
		const user = await new getToken().posteve(Tripurl,query)
		// 在做 判断操作 之前 一般都是看看请求之后返回了什么，根据你想要的情况下返回的结果从结果中取对应值进行判断。clog(user)
		// 比如user中返回了data：[] 说明查询的这个手机号并不在数据库中
		if(user.data.length > 0){
			// 已经注册过
			new result(ctx,'该手机号已被注册',202).answer() // 202指服务器接受请求，但尚未处理
		}else{
			// 没有注册过
			// [账号，密码，uid：商家唯一标识]
			// 生成商家唯一标识uid1630929117237
			// 解释：有无商家唯一标识uid都行，因为这个项目只有一个商家，如果后台是多个商家共用的话，就需要uid了
			const uid = new Date().getTime()
			const struid = JSON.stringify(uid)
			const OBJ = {account,password,uid:struid}
			const STR = JSON.stringify(OBJ)
			const addquery = `db.collection('business-acc').add({data:${STR}})`
			await new getToken().posteve(Addurl,addquery)
			new result(ctx,'注册成功').answer()
		}
	}catch(e){
		console.log(e)
		new result(ctx,'注册失败,服务器发生错误',500).answer()
	}
})


// 登录接口
router.post('/login', async ctx=>{
	let {account,password} = ctx.request.body
	const query = `db.collection('business-acc').where({account:'${account}',password:'${password}'}).get()`
	try{
		const user = await new getToken().posteve(Tripurl,query)
		// 这里调用云开发http的查询接口查到的结果user中的data的值是 [ "{"_id:xxx","account":xxx,"password":xxx}" ] 数组中每一个值都是字符串
		if(user.data.length == 0){ 
			new result(ctx,'账号或密码错误',202).answer()
		}else{
			const OBJ = JSON.parse(user.data[0]) // JSON.parse用于将一个json字符串转换为对象
			// 登录成功说明数据库已经有账号了，把查询到的账号的uid传给gentoken方法配合其他加密字符加密成token传给前端
			// 然后前端下次登录就带着这个token给后端解密，如果解到了与注册时一样的uid，就能继续操作，因为后台的所有操作都有token校验，过期了或者删了都要重新登录
			// console.log('1111');
			new result(ctx,'登录成功',200,{token:gentoken(OBJ.uid)}).answer() 
		}
	}catch(e){
		console.log(e)
		new result(ctx,'登录失败,服务器发生错误',500).answer()
	}
})


// // 验证token   因为我们这里是单商户，所以这个接口用不上。验证的思路构思了一下，前端做判断，判断localstorage之类的存不存在token，来分别访问/auth或/login接口
// router.get('/auth',new Auth().m, async ctx=>{
// 	console.log(ctx.auth.uid);
// })


// 把这个路由导出去
module.exports = router.routes()