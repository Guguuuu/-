const axios = require('axios')
const qs = require('querystring')
const result = require('./handle.js')
// 拼接tokenurl地址
let param = qs.stringify({
	grant_type:'client_credential',
	appid:'wx65867c87b5670627', // 和小程序端的appid保持一致，拿相同环境下的数据
	secret:'bd576708c6d0ec5d0f2db0724d302123'
})

// 获取token的地址：必须要得到token才有权限操作云开发数据库
let url  ='https://api.weixin.qq.com/cgi-bin/token?' + param

// 云环境id
let env = 'cloud1-5g5d06cbaa562070'

// 数据库插入记录url
let Addurl = 'https://api.weixin.qq.com/tcb/databaseadd?access_token='

// 数据库查询记录url
let Tripurl = 'https://api.weixin.qq.com/tcb/databasequery?access_token='

// 数据库更新记录url
let Updateurl = 'https://api.weixin.qq.com/tcb/databaseupdate?access_token='

// 订阅消息
let Subscribe = 'https://api.weixin.qq.com/cgi-bin/message/subscribe/send?access_token='

// 小程序码接口
let Qrcode = 'https://api.weixin.qq.com/wxa/getwxacode?access_token='

class getToken{
	constructor() {}
	
	// 用于获取token
	async gettoken(){
		try{
			let token = await axios.get(url)
			if(token.status == 200){
				return token.data.access_token
			}else{
				throw '获取token错误'
				// 出现throw这个关键词，就会进入到catch里面，并且throw给得值会在catch的参数里
			}
		}catch(e){
			throw new result(e,500)
		}
	}
	
	//posteve是一个调用云开发http api接口的方法
	async posteve(dataurl,query){ //query是操作数据库的语句
		try{
			let token = await this.gettoken()
			//dataurl就是这个云开发http接口的url
			//官方文档中所有请求类型都是post，并且请求这个接口需要token，云环境id，和数据库操作语句作为请求参数
			let data = await axios.post(dataurl + token, {env,query}) 
			if(data.data.errcode == 0){
				return data.data
			}else{
				throw '请求出错'
			}
		}catch(e){
			throw new result(e,500)
		}
	}
	
	
	// 订阅消息
	async subscribe(touser,data){
		try{
			let token = await this.gettoken()
			// touser是其中一个必带参数，是用户的openid
			let OBJ = {touser,data,template_id:'8cwZibx8QmvSa4WCQdcVfRfVwAmcMQQM0emiTV_ybds',page:'pages/my-order/my-order',miniprogram_state:'developer'}
			let colldata = await axios.post(Subscribe + token,OBJ)
			return 'success'
		}catch(err){
			throw new result(e,500)
		}
	}
	
	// 生成小程序码
	async qrcode(number){
		let token = await this.gettoken()
		// 这里规定好你生成的小程序码要跳转到哪个小程序页面，带着什么参数
		let OBJ = JSON.stringify({path:'pages/index/index?number=' + number})
		try{
			let colldata = await axios.post(Qrcode + token,OBJ,{responseType:'arraybuffer'})
			return colldata
		}catch(e){
			throw new result(e,500)
		}
	}
	
}

module.exports = {getToken,Addurl,Tripurl,Updateurl}