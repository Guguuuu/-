

1.看新增的规格设计图片：当前项目文件夹下的《规格设计图里》



2.在之前的router.post('/uploaddishes'：上架菜品接口
和router.post('/modifydishes'：编辑菜品接口
上更改代码以完成规格功能

数据库设计如下：

<!-- 补充规格功能，数据库设计上如下
 增添good_specs字段：用于提交订单的规格
 增添att_hide字段：是否有规格
 增添att_name字段：属性名
 增添specs字段：规格
 增添in_stock字段：库存
 增添specs_id字段：规格id
 
 -->
[
	{
		'category':'素菜类',//所属分类
		'cid':'a001',//分类id
		'good_query':[
			{
				image:[
					{
						status:'success',
						uid:'0000',
						url:'http'
					}
				],
				'name':'土豆丝',//商品名称
				'monthlysale':0,商品销售量
				'good_specs':'',//用于提交订单的规格
				'unitprice':20,//商品单价
				"in_stock":29,库存
				'att_hide':false,//是否有规格
				'att_name':'口味',//属性名
				'specs':[
					{
						'attribute':'微辣',
						'unitprice':10,
						"in_stock":29,库存
						'unit':'份',//商品单位
						'specs_id':'该规格id'
					},
					{
						'attribute':'中辣',
						'unitprice':20,
						"in_stock":29,库存
						'unit':'份',//商品单位
						'specs_id':'该规格id'
					},
					{
						'attribute':'中辣',
						'unitprice':10,
						"in_stock":29,库存
						'unit':'份',//商品单位
						'specs_id':'该规格id'
					}
				],
				'unit':'份',//商品单位
				'quantity':3，//商品数量
				'time':'20221-10-10 00:00:00',//上架时间
				'onsale':true,//true：上架；false：下架
				'_id':'998877767'
			}
		]
	}
]

