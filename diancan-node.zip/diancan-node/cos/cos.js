// COS 指 cloud object storage 对象存储
// 上传图片我调用腾讯云的对象存储的接口来上传
const multer = require('@koa/multer') // ① 借助第三方模块来上传图片、视频、文档等
const COS = require('cos-nodejs-sdk-v5'); // ④ 借助nodejs sdk 来把文件上传到腾讯云存储

// ⑤ 使用永久密钥初始化，密钥在文档里有跳转链接可以拿到
var cos = new COS({
   SecretId: 'AKID5xb4IG9yfIjIVbV9booXEl5KNBj1oV8b', // 这里用的是子账户的密钥，安全
   SecretKey: 'SinBKDrHScWBeuxnOineR3ayHPGrDJAn',
   Protocol:'https:' // 发请求时用的协议，可选项 https:、http
});

let Bucket = 'guguuuu-1313746603' //cos存储桶
let Region = 'ap-guangzhou' //cos地域

// ⑥ 该方法在Nodejs sdk —— 对象操作 —— 上传对象 —— 高级上传 中有介绍
let cosfun = function(filename,path){
	return new Promise((resolve,reject)=>{
		cos.uploadFile({
			Bucket, // 填自己的存储桶   这些可以在存储桶列表中复制
			Region, // 存储桶所在地域
			Key: 'image/' + filename, // 存储在存储桶里的对象键 ( 表示上传到存储桶中哪个文件夹下 )
			FilePath: path,  // FilePath的值是本地文件路径
		})
		.then(res=>{
			resolve(res.Location) // 成功之后返回的res中的Loaction是图片上传到腾讯云存储成功之后生成的在线域名，可通过浏览器查看图片
		})
		.catch(err=>{
			reject(err)
		})
	})
}

// ⑦ 二进制上传
let buffer = function(filename,path){
	return new Promise((resolve,reject)=>{
		cos.putObject({
			Bucket,
			Region,
			Key: 'image/' + filename,        /* 必须 */
			Body: Buffer.from(path),  
		})
		.then(res=>{
			resolve(res.Location)
		})
		.catch(err=>{
			reject(err)
		})
	})
}



// ② 配置上传文件 1.所在的目录和 2.更改文件名
const storage = multer.diskStorage({//磁盘存储引擎方法
	destination:(req, file, cb)=> {//存储前端传来的文件
	    cb(null, 'upload/image') //存储到upload/image下   cb是一个回调函数，到哪个文件夹，相当于做了一个指向
	},
	filename:(req, file, cb)=> { // 防止文件重名更改前缀的方法
	
		// console.log(file);  req参数用不到，前端上传的东西在file里
	
	   let fileFormat = (file.originalname).split(".")  
	   // orginalname就是你在前端上传的文件比如 xxx.jpg 通过split函数把这个"文件名字符串"分割成数组
	   
	   // 用随机数或者时间戳来拼接文件名  比如5678345321-890mnhj.jfif;.png.jpg
	   // 假设Date.now()时间戳6789045678889
	   // 那拼接得到的结果就是6789045678889-4567.jpg
	   let num = `${Date.now()}-${Math.floor(Math.random(0,1) * 10000000)}${"."}${fileFormat[fileFormat.length - 1]}`
	   cb(null,num) // 将新文件名存回去  
	   // ③ 然后有了图片之后我们就能把他上传到腾讯云存储  1.使用sdk(下载对应模块 根据文档去操作上传) 2.使用api
	   // 这里我们使用nodejs sdk，根据官方文档进行操作即可,下载并引入 ↑最上方↑
	 }
})

const upload = multer({ storage }) // 复制人家文档下的用法: 把配置好的storage做为对象传给multer(),而被赋值的upload对象就是一个中间件函数

module.exports = {upload,cosfun,buffer}