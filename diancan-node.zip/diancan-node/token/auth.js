//验证token合法性
const basicAuth = require('basic-auth')
const jwt = require('jsonwebtoken')
const security = require('./tokentime.js').security
const result = require('../config/handle.js')

class Auth{
	constructor() {}
	
	// 取值函数，用的时候不用加（） 比如new Auth().m 就能调用这个函数        set:存值函数
	get m(){//返回一个自定义中间件函数
		return async(ctx,next)=>{
			// 前端在header中传来的token在req里面,basicAuth对应的模块用于解析前端在header传来的token
			// 比如你在header中带了‘123456’，经过basicAuth解析 输出得到 Credentials {name:'123456',pass:''}
			const token = basicAuth(ctx.req) 
			if(!token || !token.name){ // 如果token或者token.name不存在
				throw new result({errcode:'401',msg:'没有访问权限'},401)
			}
			try{
				// jwt中的verify方法才是验证token是否过期是否正确，第一个参数就是加密过后的token，第二个就是参与加密的key值
				// 这个方法解析过后得到的对象格式为  { uid:'xxx', scope:2, iat:xxxx, exp:xxxx }
				var authcode = jwt.verify(token.name,security.secretkey) // 如果解析不到，就会进入catch
			}catch(error){
				// 在文档中npm的jsonwebtoken文档中查看错误类型发现error对象中有一个name值
				if(error.name == 'TokenExpiredError'){ // 这个错误类型是token过期了
					throw new result({errcode:'401',msg:'账号过期,请重新登陆'},401)
				}
				// 其他错误类型也不用过多解释，直接说没有权限即可
				throw new result({errcode:'401',msg:'没有访问权限'},401)
			}
			// 在ctx对象中追加一个值 auth，auth的值是一个对象。因为中间件之间共用同一个ctx，所以下一个中间件能拿到这个auth
			ctx.auth = {
				uid: authcode.uid
			}
			await next() // 进入下一个中间件
		}
	}
}

module.exports = {Auth}