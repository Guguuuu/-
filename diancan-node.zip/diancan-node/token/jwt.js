const jwt = require('jsonwebtoken')

const security = require('./tokentime.js').security

// token加密生成
function gentoken(uid,scope = 2){
	const secretkey = security.secretkey
	const expiresIn = security.expiresIn
	// 这个加密的方法是在对应模块下的文档找的
	// 传三个值，第一个值和第三个值都是对象，第一个对象是uid和任意一个参与加密的数字，默认给了2，第二个参数是参与加密token的值，第三个是token过期时间
	const token = jwt.sign({uid,scope},secretkey,{expiresIn}) 
	return token
}

module.exports = {gentoken}